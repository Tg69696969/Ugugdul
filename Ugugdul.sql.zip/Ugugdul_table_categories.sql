
-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `category_id` int NOT NULL AUTO_INCREMENT,
  `category_name` varchar(100) NOT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`category_id`, `category_name`) VALUES
(1, 'Аж үйлдвэр, технологи, ХАА'),
(2, 'Анагаах ухаан'),
(3, 'Бизнес, Эдийн засаг'),
(4, 'Компьютер, мэдээллийн технологи'),
(5, 'Намтар, Дурсамж'),
(6, 'Нийгмийн шинжлэх ухаан'),
(7, 'Спорт'),
(8, 'Түүх'),
(9, 'Уран зохиол'),
(10, 'Урлаг, Сөёл'),
(11, 'Философи, Шашин'),
(12, 'Хобби, Амьдралын хэв маяг'),
(13, 'Хувь хүний хөгжил, эрүүл мэнд'),
(14, 'Хууль, Эрх зүй'),
(15, 'Хэль, Толь бичиг, Нэвтэрхий толь'),
(16, 'Шинжлэх ухаан');
