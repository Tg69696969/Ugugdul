
-- --------------------------------------------------------

--
-- Table structure for table `membership_types`
--

DROP TABLE IF EXISTS `membership_types`;
CREATE TABLE IF NOT EXISTS `membership_types` (
  `membership_id` int NOT NULL AUTO_INCREMENT,
  `membership_name` varchar(50) DEFAULT NULL,
  `description` text,
  `discount_rate` decimal(5,2) DEFAULT NULL,
  PRIMARY KEY (`membership_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
