
-- --------------------------------------------------------

--
-- Table structure for table `book_details`
--

DROP TABLE IF EXISTS `book_details`;
CREATE TABLE IF NOT EXISTS `book_details` (
  `detail_id` int NOT NULL AUTO_INCREMENT,
  `book_id` int NOT NULL,
  `isbn` varchar(20) DEFAULT NULL,
  `publish_date` date DEFAULT NULL,
  `format` varchar(100) DEFAULT NULL,
  `pages` int DEFAULT NULL,
  `publisher` varchar(255) DEFAULT NULL,
  `language` varchar(100) DEFAULT NULL,
  `weight` int DEFAULT NULL,
  `dimensions` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`detail_id`),
  KEY `book_id` (`book_id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `book_details`
--

INSERT INTO `book_details` (`detail_id`, `book_id`, `isbn`, `publish_date`, `format`, `pages`, `publisher`, `language`, `weight`, `dimensions`) VALUES
(1, 1, '978-99973-1-538-10', '2022-03-01', 'Hardcover', 220, 'Tech Industry Press', 'Монгол', 320, '150 x 220 x 20 мм'),
(2, 2, '978-99973-1-538-11', '2021-05-15', 'Softcover', 180, 'MedHealth Center', 'Монгол', 200, '140 x 200 x 18 мм'),
(3, 3, '978-99973-1-538-12', '2020-09-10', 'Softcover', 250, 'Business Hub', 'Монгол', 260, '145 x 210 x 20 мм'),
(4, 4, '978-99973-1-538-13', '2022-01-20', 'Softcover', 300, 'IT World', 'Монгол', 270, '150 x 230 x 22 мм'),
(5, 5, '978-99973-1-538-14', '2019-08-25', 'Hardcover', 200, 'Biography Center', 'Монгол', 310, '160 x 240 x 20 мм'),
(6, 6, '978-99973-1-538-15', '2018-06-17', 'Softcover', 190, 'Social Science Press', 'Монгол', 230, '140 x 200 x 16 мм'),
(7, 7, '978-99973-1-538-16', '2020-03-05', 'Softcover', 160, 'Sporting Life', 'Монгол', 210, '130 x 190 x 15 мм'),
(8, 8, '978-99973-1-538-17', '2021-11-11', 'Hardcover', 270, 'History Mongol', 'Монгол', 350, '160 x 240 x 25 мм'),
(9, 9, '978-99973-1-538-18', '2022-06-12', 'E-book', 0, 'Literature Hub', 'Монгол', 0, 'N/A'),
(10, 10, '978-99973-1-538-19', '2020-07-19', 'Softcover', 230, 'Arts Mongolia', 'Монгол', 280, '150 x 220 x 19 мм'),
(11, 11, '978-99973-1-538-20', '2019-10-28', 'Hardcover', 260, 'Philo Press', 'Монгол', 300, '160 x 230 x 20 мм'),
(12, 12, '978-99973-1-538-21', '2022-02-10', 'Softcover', 210, 'Lifestyle Books', 'Монгол', 250, '145 x 210 x 18 мм'),
(13, 13, '978-99973-1-538-22', '2020-12-01', 'Softcover', 200, 'Self Help Center', 'Монгол', 240, '140 x 200 x 16 мм'),
(14, 14, '978-99973-1-538-23', '2018-09-15', 'Hardcover', 280, 'Law Books', 'Монгол', 320, '160 x 240 x 22 мм'),
(15, 15, '978-99973-1-538-24', '2021-01-30', 'Hardcover', 350, 'Lexicon Publishing', 'Монгол', 400, '170 x 250 x 30 мм'),
(16, 16, '978-99973-1-538-25', '2019-04-05', 'Softcover', 300, 'Science Knowledge', 'Монгол', 310, '150 x 220 x 20 мм'),
(17, 17, '978-9919-0-4081-9', '2025-02-18', 'Зөөлөн хавтастай', 184, 'АШУҮИС', 'MN', NULL, '205 x 145 x 10 мм'),
(18, 18, NULL, NULL, 'Зөөлөн хавтастай', NULL, NULL, 'MN', NULL, NULL);
