
-- --------------------------------------------------------

--
-- Table structure for table `stock_logs`
--

DROP TABLE IF EXISTS `stock_logs`;
CREATE TABLE IF NOT EXISTS `stock_logs` (
  `log_id` int NOT NULL AUTO_INCREMENT,
  `book_id` int DEFAULT NULL,
  `action` enum('add','remove') NOT NULL,
  `quantity` int NOT NULL,
  `action_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`log_id`),
  KEY `book_id` (`book_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
