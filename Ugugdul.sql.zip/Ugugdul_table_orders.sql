
-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
CREATE TABLE IF NOT EXISTS `orders` (
  `order_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `order_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(50) DEFAULT 'pending',
  `receiver_name` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `city` varchar(50) NOT NULL,
  `district` varchar(50) NOT NULL,
  `address` text NOT NULL,
  PRIMARY KEY (`order_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `user_id`, `order_date`, `status`, `receiver_name`, `phone`, `city`, `district`, `address`) VALUES
(1, 1, '2025-05-03 21:55:55', 'pending', '', '', '', '', ''),
(2, 1, '2025-05-03 21:56:01', 'pending', '', '', '', '', ''),
(3, 1, '2025-05-03 21:56:38', 'pending', '', '', '', '', ''),
(4, 1, '2025-05-04 15:50:08', 'confirmed', '', '', '', '', ''),
(5, 1, '2025-05-04 15:50:13', 'confirmed', '', '', '', '', ''),
(6, 1, '2025-05-04 15:50:17', 'confirmed', '', '', '', '', ''),
(7, 1, '2025-05-04 16:30:06', 'confirmed', '', '', '', '', ''),
(8, 1, '2025-05-04 16:30:19', 'confirmed', '', '', '', '', ''),
(9, 1, '2025-05-04 16:30:50', 'confirmed', '', '', '', '', ''),
(10, 1, '2025-05-04 16:56:11', 'confirmed', '', '', '', '', ''),
(11, 1, '2025-05-04 16:56:44', 'confirmed', '', '', '', '', ''),
(12, 1, '2025-05-04 16:57:39', 'confirmed', '', '', '', '', ''),
(13, 1, '2025-05-04 16:58:00', 'confirmed', '', '', '', '', ''),
(14, 1, '2025-05-04 17:14:36', 'confirmed', '', '', '', '', ''),
(15, 1, '2025-05-04 17:16:54', 'confirmed', '', '', '', '', ''),
(16, 1, '2025-05-04 17:43:10', 'confirmed', 'Tuguldur KH', '90313236', 'Ulaanbaatar', 'asdfas', 'elearn.sict.edu.mn'),
(17, 1, '2025-05-04 17:53:48', 'confirmed', 'Tuguldur KH', '90313236', 'Ulaanbaatar', 'ada', 'elearn.sict.edu.mn'),
(18, 1, '2025-05-04 17:59:24', 'confirmed', 'Tuguldur KH', '90313236', 'Ulaanbaatar', 'sadasd', 'elearn.sict.edu.mn'),
(19, 1, '2025-05-04 18:00:00', 'confirmed', 'Tuguldur KH', '90313236', 'Ulaanbaatar', 'sds', 'elearn.sict.edu.mn'),
(20, 1, '2025-05-04 18:11:28', 'confirmed', 'Tuguldur KH', '90313236', 'Ulaanbaatar', 'sasa', 'elearn.sict.edu.mn'),
(21, 1, '2025-05-04 18:11:56', 'confirmed', 'Tuguldur KH', '90313236', 'Ulaanbaatar', 'ada', 'elearn.sict.edu.mn'),
(22, 1, '2025-05-04 18:12:46', 'confirmed', 'Tuguldur KH', '90313236', 'Ulaanbaatar', 'asdfas', 'elearn.sict.edu.mn'),
(23, 1, '2025-05-04 18:13:07', 'confirmed', 'Tuguldur KH', '90313236', 'Ulaanbaatar', 'sasdas', 'elearn.sict.edu.mn'),
(24, 1, '2025-05-04 18:13:27', 'confirmed', 'dasda', 'asdaas', 'asdad', 'asdad', 'asdad'),
(25, 1, '2025-05-04 18:13:54', 'confirmed', 'asd', 'asdsa', 'dasd', 'asda', 'asda'),
(26, 1, '2025-05-04 18:17:45', 'confirmed', 'Tuguldur KH', '90313236', 'Ulaanbaatar', 'ghgh', 'elearn.sict.edu.mn'),
(27, 1, '2025-05-04 18:25:56', 'confirmed', 'Tuguldur KH', '90313236', 'Ulaanbaatar', 'KKJ', 'elearn.sict.edu.mn'),
(28, 1, '2025-05-04 18:26:41', 'confirmed', 'Tuguldur KH', '90313236', 'Ulaanbaatar', 'asdad', 'elearn.sict.edu.mn'),
(29, 1, '2025-05-04 18:27:09', 'confirmed', 'Tuguldur KH', '90313236', 'Ulaanbaatar', 'kmkjo', 'elearn.sict.edu.mn'),
(30, 1, '2025-05-04 18:30:03', 'confirmed', 'fdsf', 'fdsffs', 'fdsfdsf', 'sdfsf', 'sdff'),
(31, 1, '2025-05-04 18:35:08', 'confirmed', 'tg', '0392093', '123', '1231', '1231'),
(32, 1, '2025-05-04 18:38:21', 'confirmed', '', '', '', '', ''),
(33, 1, '2025-05-04 18:38:24', 'confirmed', '', '', '', '', ''),
(34, 1, '2025-05-04 18:38:29', 'confirmed', '', '', '', '', ''),
(35, 1, '2025-05-04 18:38:41', 'confirmed', '', '', '', '', ''),
(36, 1, '2025-05-04 18:40:39', 'confirmed', '', '', '', '', ''),
(37, 1, '2025-05-04 18:40:42', 'confirmed', '', '', '', '', ''),
(38, 1, '2025-05-04 18:43:23', 'confirmed', 'tg', 'sadf', 'sdfas', 'asdf', 'asf'),
(39, 1, '2025-05-04 18:56:17', 'confirmed', 'asd', 'asda', 'asd', 'dad', 'asd'),
(40, 1, '2025-05-04 18:57:41', 'confirmed', 'dwea', 'asdas', 'das', 'asdasd', 'asda'),
(41, 1, '2025-05-04 19:12:41', 'confirmed', '', '', '', '', ''),
(42, 1, '2025-05-04 19:37:30', 'confirmed', 'Tuguldur KH', '90313236', 'Ulaanbaatar', 'j', 'elearn.sict.edu.mn'),
(43, 1, '2025-05-04 19:46:54', 'confirmed', 'Tuguldur KH', '90313236', 'Ulaanbaatar', 'sas', 'elearn.sict.edu.mn'),
(44, 1, '2025-05-04 19:55:30', 'confirmed', 'Tuguldur KH', '90313236', 'Ulaanbaatar', 'dasd', 'elearn.sict.edu.mn'),
(45, 1, '2025-05-04 20:01:40', 'confirmed', 'wrerwrw', 'asd', 'dasda', 'asdas', 'asdad'),
(46, 1, '2025-05-04 20:32:40', 'confirmed', 'vgh', 'ghvh', 'ghvh', 'hv ', 'ghv'),
(47, 1, '2025-05-04 20:34:07', 'confirmed', '', '', '', '', ''),
(48, 1, '2025-05-05 02:10:36', 'confirmed', 'dasdda', 'dasd', 'asd', 'asd', 'asd'),
(49, 1, '2025-05-05 09:45:20', 'confirmed', '', '', '', '', '');
